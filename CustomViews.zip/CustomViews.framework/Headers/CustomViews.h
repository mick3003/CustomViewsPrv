//
//  CustomViews.h
//  CustomViews
//
//  Created by Miguel Estévez on 14/11/2018.
//  Copyright © 2018 Miguel Estévez. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CustomViews.
FOUNDATION_EXPORT double CustomViewsVersionNumber;

//! Project version string for CustomViews.
FOUNDATION_EXPORT const unsigned char CustomViewsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CustomViews/PublicHeader.h>


